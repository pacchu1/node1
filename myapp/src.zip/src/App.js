/*import logo from './logo.svg';*/
import "./App.css";
import Novbar from './Novbar';
import{BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import Home from './Home';
/*import bar  from './styles/Novbar.css';*/
import { Link } from 'react-router-dom';
import About from './About';
import Contact from './Contact';
import Gallary from './Gallary';
import Course from './Course';

/*import course from './styles/course.css';
import gallary from './styles/gallary.css';
import novbar from './styles/Novbar.css';

import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';*/
function App() {
  return (
    <div className="App">
  
      <Router>
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/About' element={<About/>}/>
          <Route path='/Contact' element={<Contact/>}/>
          <Route path='/Gallary' element={<Gallary/>}/>
          <Route path='/Course' element={<Course/>}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
