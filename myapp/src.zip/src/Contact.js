import React from 'react'
import image from '../src/images/subbi.jpeg';
import image1 from '../src/images/gubbi.jpeg';
import image2 from '../src/images/dummi.jpeg';
const Contact = () => {
  return (
    <div>
      <h1 className='contact'>Contact us for more information</h1>
      <h2 className='contact1'>Welcome To React Js</h2>
    <marquee className='move'> Choose from over 210,000 online video courses with new additions published every month

....</marquee>
<div className='tum'>
<img className='che' src={image} alt='plant' />
<img  className='tu'  src={image1} alt='plant' />
<img  className='papa' src={image2} alt='plant' />
</div>
    </div>
  )
}

export default Contact
