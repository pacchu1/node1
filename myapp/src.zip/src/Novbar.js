import React from 'react'
import About from './About';
import { Link } from 'react-router-dom';
import Contact from './Contact';
import Gallary from './Gallary';
import Course from './Course';
import image from '../src/images/logo1.png';
import nov from './styles/Novbar.css';
const Novbar = () => {
  return (
    <div>
      
      <header>
      
      {/* <img className='logo' src={image} alt='plant' /> */}
    
      <Link className='beda' to='/About'>About Us</Link>
      <Link className='beda' to='/Contact'>Contact Us</Link>
      <Link className='beda' to='/Gallary'>Gallary</Link>
      <Link className='beda' to='/Course'>Course</Link>
      </header>
    </div>
  )
}

export default Novbar
