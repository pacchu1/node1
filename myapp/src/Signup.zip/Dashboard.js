import React, { useState } from 'react';

 // Import the Nav1 component
import './styles/dash.css'
const Dashboard = () => {
    const [activeButton, setActiveButton] = useState('Home');

  const handleButtonClick = (buttonName) => {
    setActiveButton(buttonName);
  };
  
    return (
        <div className='nanu2'>
        <div className='nan'>
                    <div className="dashboard">
            <div className="user-info">
                <div className="user-icon">
                    <img src="https://img.freepik.com/free-vector/businessman-character-avatar-isolated_24877-60111.jpg?size=626&ext=jpg&ga=GA1.1.398881765.1690430410&semt=ais" alt="User Icon" />
                </div>
                <div className="user-details">
                    <p className="name">SAHANA THIMMAYYA</p>
                    <p className="email">tsahana8@gmail.com</p>
                    <p className="other-info">Software developer</p>
                    
        
      
      
                </div>
                <div className="sidebar">
        <button
          className={`sidebar-button ${activeButton === 'Home' ? 'active' : ''}`}
          onClick={() => handleButtonClick('Home')}
        >
          Home
        </button>
        <button
          className={`sidebar-button ${activeButton === 'MyResult' ? 'active' : ''}`}
          onClick={() => handleButtonClick('MyResult')}
        >
          My Result
        </button>
        <button
          className={`sidebar-button ${activeButton === 'Submission' ? 'active' : ''}`}
          onClick={() => handleButtonClick('Submission')}
        >
          Submission
        </button>
        <button
          className={`sidebar-button ${activeButton === 'Tutorials' ? 'active' : ''}`}
          onClick={() => handleButtonClick('Tutorials')}
        >
          Tutorials
        </button>
        <button
          className={`sidebar-button ${activeButton === 'Settings' ? 'active' : ''}`}
          onClick={() => handleButtonClick('Settings')}
        >
          Settings
        </button>
      </div>

      <div className="content">
        {/* You can render the content of the selected button here */}
        {activeButton === 'Home' && <div></div>}
        {activeButton === 'MyResult' && <div></div>}
        {activeButton === 'Submission' && <div></div>}
        {activeButton === 'Tutorials' && <div></div>}
        {activeButton === 'Settings' && <div></div>}
      </div>
    </div>

            </div>
                    </div>
                    </div>      

    );
};

export default Dashboard;


