// import React from 'react'
// import { useLocation } from 'react-router-dom'
// import './styles/formdata.css';
// const Formdata = () => {
//     const data=useLocation().state.Submitteddata;
//     return (
//       <div className='register'>
//         <h1>Registration Form</h1>
//         <p1>First Name:{data.firstName}</p1><br></br>
//         <p1>Last Name:{data.LastName}</p1><br></br>
//         <p1>Email:{data.email}</p1><br></br>
//         <p1>DOB:{data.dob}</p1><br></br>
//         <p1>Gender:{data.gender}</p1>
       
//       </div>
//     )
//   }
  

// export default Formdata
import React from 'react'
import { useLocation } from 'react-router-dom'
const Formdata = () => {
    const data=useLocation().state.Submitteddata;
  return (
    <div>
      <h1>registration Form</h1>
      <p1>{data.firstName}</p1>
      <p1>{data.LastName}</p1>
      <p1>{data.email}</p1>
      <p1>{data.dob}</p1>
     
    </div>
  )
}

export default Formdata;