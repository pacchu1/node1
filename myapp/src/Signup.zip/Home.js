import React from 'react'
import Novbar from './Novbar';
import image from '../src/images/pacchu.png';
import { Link } from 'react-router-dom';
// import About from './About';
// import Contact from './Contact';
// import Gallary from './Gallary';
// import Course from './Course';
/*import novbar from './styles/Novbar.css';*/
import './styles/home.css';

const Home = () => {
  return (
    <div className='boo'>
    
    
     
      <h1 className='white'>Welcome to React</h1>
      
      <img src={image} alt='plant' />
    
    </div>
  )
}

export default Home
