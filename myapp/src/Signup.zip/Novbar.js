import React, { useState } from 'react';

import About from './About';
import { Link } from 'react-router-dom';
import Contact from './Contact';
import Gallary from './Gallary';
import Course from './Course';
import image from '../src/images/logo1.png';
import './styles/Novbar.css';

//  Novbar = () => {
//   const [isBoxOpen, setIsBoxOpen] = useState(false);

  const toggleBox = () => {
    setIsBoxOpen(!isBoxOpen)
  return (
    <div className='nav'>
      
    
      
      {/* <img className='logo' src={image} alt='plant' /> */}
      <Link className='beda' to='/Home'>Home</Link>
      <Link className='beda' to='/About'>About Us</Link>
      <Link className='beda' to='/Contact'>Contact Us</Link>
      <Link className='beda' to='/Gallary'>Gallary</Link>
      <Link className='beda' to='/Course'>Course</Link>
      <Link className='beda' to='/Signin'>Signin</Link>
      <Link className='beda' to='/Signup'>Signup</Link>
      <button className="bedaninu" onClick={toggleBox}>
        <svg xmlns="http://www.w3.org/2000/svg" width="56" height="56" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
          <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
          <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z" />
        </svg>
      </button>

      {isBoxOpen && (
        <div className="user-box">
          {/* Content of the user box */}
          <p>User Icon</p>
          <p>Email ID</p>
          <button onClick={toggleBox}>Cancel</button>
        </div>

  </div>
      
    
  )
};

export default Novbar;
