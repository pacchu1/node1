
import React, { useState } from 'react';
import "./styles/register.css"
import { useNavigate } from 'react-router-dom';

//import { Link } from 'react-router-dom';
// const Register() {
//   const [formData, setFormData] = useState({
//     firstName: '',
//     lastName: '',
//     dob: '',
//     email: '',
//   });

//   const registerUser = () => {
//     // Perform client-side validation

//     // Simulate server registration by storing data in local storage
//     localStorage.setItem('user', JSON.stringify(formData));
    
//     // Redirect to the login page or take other actions
//   };
// // Register.js
import React, { useState } from 'react';

const Register = ({ history }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleRegister = () => {
    // Add logic to handle registration (e.g., sending data to a server, storing in state, etc.)
    // After successful registration, redirect to the login page
    history.push('/login');
  };

  return (
    <div>
      <h2>Registration Page</h2>
      <input type="text" name="firstName" placeholder="First Name" onChange={handleInputChange} />
      <input type="text" name="lastName" placeholder="Last Name" onChange={handleInputChange} />
      <input type="email" name="email" placeholder="Email" onChange={handleInputChange} />
      <input type="password" name="password" placeholder="Password" onChange={handleInputChange} />
      <button onClick={handleRegister}>Register</button>
    </div>
  );
};

export default Register;
