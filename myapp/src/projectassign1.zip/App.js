//import './App.css';
//import About from './About.js';
//import Catagary from './Catagary';
//import Home from './Home';
//import Event from './Event';
 import Footer from './Footer';
//import Navbar from './Navbar';
//import Signin from './Signin';
// import Signup from './Signup';
 import Dashboard from './Dashboard.js';
// //import Name1 from './Name1';
// import Navbar from './Navbar';
import React from 'react';
//import Handle from './handle';
import Form from './Form';
import 'mdb-react-ui-kit/dist/css/mdb.min.css';
import "@fortawesome/fontawesome-free/css/all.min.css";
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom'
import Formdata from './Formdata';
//import Nav1 from './Nav1';
function App() {
  return (
    <div className="App">
       <div>
        
        <Router> 
          {/* <Navbar/> */}
         <Routes>
         
          
           {/* <Route path="/" element ={<Navbar/>}/> */}
           {/* <Route path="/Formdata" element ={<Formdata/>}/> */}
            <Route path="/" element ={<Form/>}/>
           <Route path="/Formdata" element ={<Formdata/>}/>
           <Route path="/Dashboard" element ={<Dashboard/>}/> 
           <Route path="/Footer" element ={<Footer/>}/>
           {/* <Route path="/Event" element ={<Event/>}/>
           
           <Route path="/About" element ={<About/>}/>
           <Route path="/Catagary" element ={<Catagary/>}/>
           <Route path="/Signin" element ={<Signin/>}/> 
            <Route path="/Signup" element ={<Signup/>}/> 
            */}
          
         </Routes>
        </Router>
     </div>
 
     </div>
  );
}

export default App;
